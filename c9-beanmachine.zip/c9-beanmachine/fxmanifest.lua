fx_version 'cerulean'
game 'gta5'

author '1_x.x_1'

description 'c9-beanmachine'
version '1.0.0'

shared_scripts {
    'config.lua'
}

client_scripts {
	'client/client.lua',
	'client/menus.lua'
}

server_script {
	'server/server.lua'
} 
