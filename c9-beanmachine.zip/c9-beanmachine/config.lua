Config = {}

Config.SQL = 'oxmysql' --- oxmysql or ghmattisql

Config.Items = {
    label = "Shop",
        slots = 7,
        items = {
            [1] = {
                name = "cocabeans",
                price = 100,
                amount = 1000,
                info = {},
                type = "item",
                slot = 1,
            },
            [2] = {
                name = "whipcream",
                price = 100,
                amount = 1000,
                info = {},
                type = "item",
                slot = 2,
            },
            [3] = {
                name = "chocolate",
                price = 300,
                amount = 1000,
                info = {},
                type = "item",
                slot = 3,
            },
            [4] = {
                name = "sprinkles",
                price = 300,
                amount = 1000,
                info = {},
                type = "item",
                slot = 4,
            },
            [5] = {
                name = "milkbottle",
                price = 300,
                amount = 1000,
                info = {},
                type = "item",
                slot = 5,
            },
            [6] = {
                name = "teabag",
                price = 100,
                amount = 1000,
                info = {},
                type = "item",
                slot = 6,
            },
        }
    }
    