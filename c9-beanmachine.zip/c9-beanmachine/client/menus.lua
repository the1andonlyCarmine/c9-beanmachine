local QBCore = exports['qb-core']:GetCoreObject()
isLoggedIn = true
PlayerJob = {}

local onDuty = false

Citizen.CreateThread(function()

 
    exports['qb-target']:AddBoxZone("BeanMachineDuty", vector3(-484.06, -143.6, 39.96), 0.4, 1, {
        name="BeanMachineDuty",
        heading=355,
        debugPoly=false,
    }, {
        options = {
            {
            event = "c9-beanmachine:DutyA",
            icon = "far fa-clipboard",
            label = "Clock On/Off",
            job = "beanmachine",
            },
        },
        distance = 1.5    
    })

    exports['qb-target']:AddBoxZone("Fridge1", vector3(-486.12, -144.7, 39.96), 1, 1, {
		name="Fridge1",
		heading=300,
		debugPoly=false,
	}, {
		options = {
		    {
			event = "c9-beanmachine:Fridge",
			icon = "fa fa-archive",
			label = "Fridge",
            job = "beanmachine",
		    },
		},
		distance = 1.5
	})

	exports['qb-target']:AddBoxZone("Tray1", vector3(-488.27, -142.1, 39.7), 0.4, 1, {
		name="Tray1",
		heading=5,
		debugPoly=false,
	}, {
		options = {
		    {
			event = "c9-beanmachine:Tray1",
			icon = "far fa-clipboard",
			label = "Tray 1",
		    },
		},
		distance = 1.5
	})

    exports['qb-target']:AddBoxZone("DrinksMaker", vector3(-485.02, -141.26, 39.96), 0.4, 1, {
		name="DrinksMaker",
		heading=295,
		debugPoly=false,
	}, {
		options = {
		    {
			event = "c9-beanmachine:DrinksMenu",
			icon = "fa fa-coffee",
			label = "Make Drinks",
            job = "beanmachine",
		    },
		},
		distance = 1.5
	})

    exports['qb-target']:AddBoxZone("Foods", vector3(-489.48, -143.54, 39.96), 0.6, 1, {
		name="Foods",
		heading=30,
		debugPoly=false,
	}, {
		options = {
		    {
			event = "c9-beanmachine:FoodMenu",
			icon = "fa fa-cutlery",
			label = "Make Foods",
            job = "beanmachine",
		    },
		},
		distance = 1.5
	})

    exports['qb-target']:AddBoxZone("Cashier", vector3(-488.11, -142.88, 39.96), 0.4, 1, {
		name="Cashier",
		heading=30,
		debugPoly=false,
	}, {
		options = {
		    {
			event = "c9-beanmachine:bill",
			icon = "fas fa-credit-card",
			label = "Cashier",
            job = "beanmachine",
		    },
		},
		distance = 1.5
	})

end)
      
RegisterNetEvent('c9-beanmachine:DrinksMenu', function(data)

    exports['qb-menu']:openMenu({
        {
           header = "Drinks Menu",
           isMenuHeader = true,
        },

        {
            header = "☕ Coffee",
            txt = "3 Cocabeans and 1 Milk Bottle Required",
            params = {
                event = "c9-beanmachine:CreateCafe", 
                args = {
                    number = 0,
               }
           }
        },
        {
            header = "☕ Latte",
            txt = "3 Cocabeans and 1 Milk Bottle Required",
            params = {
                event = "c9-beanmachine:CreateLatte",
                args = {
                    number = 1,
               }
           }
        },
        {
            header = "☕ Cappuccino",
            txt = "3 Cocabeans and 2 Milk Bottles Required",
            params = {
                event = "c9-beanmachine:CreateCappuccino",
                args = {
                    number = 2,
                }
            }
        },
        {
            header = "☕ Mocha",
            txt = "1 Milk Bottle , 3 Cocabeans and 1 Whipcream Required",
            params = {
                event = "c9-beanmachine:CreateMocha",
                args = {
                    number = 3,
                }
            }
        },
        {
            header = "🥤 Choclate Milkshake",
            txt = "2 Milk Bottles , 5 Chocolates and 1 Whipcream Required",
            params = {
                event = "c9-beanmachine:CreateCMilkshake",
                args = {
                    number = 4,
                }
            }
        },
        {
            header = "🥤 Ice Tea",
            txt = "1 Teabag Required",
            params = {
                event = "c9-beanmachine:CreateIcetea",
                args = {
                    number = 5,
                }
            }
        },                 

       {
           header = "❌ Close",
           txt = "",
           params = {
               event = "qb-menu:closeMenu",
               args = {
                   number = 6,
               }
           }
       },
   })
   end)

RegisterNetEvent('c9-beanmachine:Fridge', function(data)

    exports['qb-menu']:openMenu({
       {
           header = "Storage Container",
           isMenuHeader = true,
       },

       {
           header = "📦 Fridge",
           txt = "Open the Fridge",
           params = {
               event = "c9-beanmachine:Storage", 
               args = {
                   number = 0,
               }
           }
       },
       {
           header = "🛍️ Shop",
           txt = "Shop For Ingredients",
           params = {
               event = "c9-beanmachine:shop",
               args = {
                   number = 1,
               }
           }
       },   

       {
           header = "❌ Close",
           txt = "",
           params = {
               event = "qb-menu:closeMenu",
               args = {
                   number = 2,
               }
           }
       },
   })
   end)

RegisterNetEvent('c9-beanmachine:FoodMenu', function(data)

    exports['qb-menu']:openMenu({
        {
           header = "Food Menu",
           isMenuHeader = true,
        },

        {
            header = "🍩 Donut",
            txt = "5 Sprinkles Required",
            params = {
                event = "c9-beanmachine:CreateDonut", 
                args = {
                    number = 0,
               }
           }
        },
        {
            header = "🥐 Croissant",
            txt = " 2 Milk Bottles Required",
            params = {
                event = "c9-beanmachine:CreateCroissant",
                args = {
                    number = 1,
               }
           }
        },
        {
            header = "🧁 Chocolate Cupcake",
            txt = "7 Chocolates Required",
            params = {
                event = "c9-beanmachine:CreateChocolateCupcake",
                args = {
                    number = 2,
                }
            }
        },
        {
            header = "🍪 Cookie",
            txt = "5 Chocolates Required",
            params = {
                event = "c9-beanmachine:CreateCookie",
                args = {
                    number = 3,
                }
            }
        },

        {
            header = "❌ Close",
            txt = "",
            params = {
                event = "qb-menu:closeMenu",
                args = {
                    number = 4,
                }
            }
        },
    })
    end)        

----------------Billing-----------------------

RegisterNetEvent("c9-beanmachine:bill", function()
    local dialog = exports['qb-input']:ShowInput({
        header = "Cash Register",
        submitText = "Charge Customer",
        inputs = {
            {
                type = 'number',
                isRequired = true,
                name = 'id',
                text = 'Paypal ID'
            },
            {
                type = 'number',
                isRequired = true,
                name = 'amount',
                text = '$ amount!'
            }
        }
    })
    if dialog then
        if not dialog.id or not dialog.amount then return end
        TriggerServerEvent("c9-beanmachine:bill:player", dialog.id, dialog.amount)
    end
end)
